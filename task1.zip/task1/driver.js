"use strict";

let blindSignatures = require('blind-signatures');
let BigInteger = require('jsbn').BigInteger;

let SpyAgency = require('./spyAgency.js').SpyAgency;

function makeDocument(coverName) {
  return `The bearer of this signed document, ${coverName}, has full diplomatic immunity.`;
}

function blind(msg, n, e) {
  return blindSignatures.blind({
    message: msg,
    N: new BigInteger(n),
    E: new BigInteger(e),
  });
}

function unblind(r, signed, n) {
  return blindSignatures.unblind({
    signed: signed,
    N: new BigInteger(n),
    r: r,
  });
}

// 🕵️ إنشاء الوكالة
let agency = new SpyAgency();

let documents = [];
let blindDocs = [];
let blindFactors = [];

// 👤 توليد 10 وثائق وتعمية كل واحدة
for (let i = 0; i < 10; i++) {
  let doc = makeDocument(`Agent_${i}`);
  documents.push(doc);

  let { blinded, r } = blind(doc, agency.n, agency.e);
  blindDocs.push(blinded);
  blindFactors.push(r);
}

agency.signDocument(blindDocs, (selected, verifyAndSign) => {
  console.log(`Agency selected document #${selected}`);

  // إنشاء نسخ من المصفوفات لتجنب المشاكل المرجعية
  let filteredDocs = [...documents];
  let filteredFactors = [...blindFactors];

  // إزالة العنصر المختار
  filteredDocs.splice(selected, 1);
  filteredFactors.splice(selected, 1);

  try {
    let signedBlinded = verifyAndSign(filteredFactors, filteredDocs);
    // ... باقي الكود
  } catch (e) {
    console.error("Error during verification:", e);
  }
});
